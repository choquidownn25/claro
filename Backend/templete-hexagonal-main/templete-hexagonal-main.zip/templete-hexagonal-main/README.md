# templete-hexagonal

![userrolemembership1](https://github.com/choquidownn25/templete-hexagonal/blob/main/img/List.jpg)
![userrolemembership2](https://github.com/choquidownn25/templete-hexagonal/blob/main/img/Post.jpg)
# Features

- spring initializr https://start.spring.io/
- Maven
- Java 19
- Web API 
- Lombok
- JPA
- Struct Map
- Validation
- Swagger 2


# Development Tools & Environment

- **IntelliJ IDEA 2021.1.3 (Community Edition). (https://www.jetbrains.com/idea/promo/)
- **Tabnine. (https://www.tabnine.com/)