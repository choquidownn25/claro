insert into BOOK (id, title, description, price) values (1,'Clean Code','A handbook of agile Software',30);
insert into BOOK (id, title, description, price) values (2,'Playing with Java Microservices','Microservices Book',20);
insert into BOOK (id, title, description, price) values (3,'Spring in actions','spring Book',25);
insert into BOOK (id, title, description, price) values (4,'Head First java','java book',25);
insert into BOOK (id, title, description, price) values (5,'Hands-on spring boot','spring boot book',40);


